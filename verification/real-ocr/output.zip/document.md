## 离线文档识别验证


这是一张新生成的单页测试图片。


输入在识别前保存，模型在本地运行。


结果包括文字、公式、表格和插图。


## 能量公式


$$
\mathrm{E}=\mathrm{mc}^{2}
$$

## 商品统计


<table><tr><td>商品</td><td>数量</td><td>金额</td></tr><tr><td>钢笔</td><td>3</td><td>45</td></tr><tr><td>笔记本</td><td>2</td><td>30</td></tr></table>

![插图](assets/p0001-b0009.png)

图 1：圆形与三角形

